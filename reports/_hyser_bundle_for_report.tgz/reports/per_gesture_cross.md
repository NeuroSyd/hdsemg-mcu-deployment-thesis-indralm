|   gesture | name                         |   trials |   LDA |   1D CNN |   TCN |   GRU |
|----------:|:-----------------------------|---------:|------:|---------:|------:|------:|
|         1 | G01 Thumb ext                |      119 |  30.3 |     38.7 |  49.6 |  47.9 |
|         2 | G02 Index ext                |      120 |  34.2 |     57.5 |  60   |  73.3 |
|         3 | G03 Middle ext               |      120 |  31.7 |     60   |  65.8 |  67.5 |
|         4 | G04 Ring ext                 |      109 |  32.1 |     58.7 |  52.3 |  71.6 |
|         5 | G05 Little ext               |      120 |  36.7 |     58.3 |  60   |  82.5 |
|         6 | G06 Wrist flex               |      120 |  16.7 |     43.3 |  39.2 |  56.7 |
|         7 | G07 Wrist ext                |      119 |  37   |     53.8 |  37   |  61.3 |
|         8 | G08 Wrist radial             |      114 |  27.2 |     38.6 |  43   |  51.8 |
|         9 | G09 Wrist ulnar              |      119 |  23.5 |     56.3 |  48.7 |  56.3 |
|        10 | G10 Wrist pronation          |      116 |  25   |     54.3 |  59.5 |  67.2 |
|        11 | G11 Wrist supination         |      114 |  17.5 |     53.5 |  50   |  50.9 |
|        12 | G12 Thumb+index ext          |      120 |  34.2 |     65.8 |  63.3 |  66.7 |
|        13 | G13 Index+middle ext         |      120 |  27.5 |     53.3 |  58.3 |  64.2 |
|        14 | G14 Wrist flex + close       |      120 |  35   |     49.2 |  54.2 |  58.3 |
|        15 | G15 Wrist ext + close        |      120 |  34.2 |     58.3 |  60   |  65.8 |
|        16 | G16 Wrist radial + close     |      119 |  29.4 |     35.3 |  37   |  47.9 |
|        17 | G17 Wrist ulnar + close      |      119 |  23.5 |     54.6 |  58.8 |  66.4 |
|        18 | G18 Wrist pron + close       |      119 |  26.9 |     61.3 |  58.8 |  60.5 |
|        19 | G19 Wrist sup + close        |      120 |  24.2 |     52.5 |  33.3 |  38.3 |
|        20 | G20 Wrist flex + open        |      120 |  19.2 |     45.8 |  58.3 |  39.2 |
|        21 | G21 Wrist ext + open         |      120 |  35   |     68.3 |  63.3 |  63.3 |
|        22 | G22 Wrist radial + open      |      120 |  34.2 |     39.2 |  52.5 |  56.7 |
|        23 | G23 Wrist ulnar + open       |      120 |  23.3 |     60   |  65.8 |  58.3 |
|        24 | G24 Wrist pron + open        |      119 |  23.5 |     78.2 |  58   |  60.5 |
|        25 | G25 Wrist sup + open         |      114 |  28.1 |     74.6 |  58.8 |  57   |
|        26 | G26 Thumb+index+middle ext   |      118 |  16.1 |     56.8 |  47.5 |  66.9 |
|        27 | G27 Index+middle+ring ext    |      120 |  25   |     63.3 |  50   |  64.2 |
|        28 | G28 Middle+ring+little ext   |      120 |  24.2 |     49.2 |  48.3 |  55   |
|        29 | G29 Index to little ext      |      120 |  36.7 |     38.3 |  49.2 |  41.7 |
|        30 | G30 Hand close               |      120 |  21.7 |     65   |  68.3 |  61.7 |
|        31 | G31 Hand open                |      120 |  22.5 |     48.3 |  45   |  51.7 |
|        32 | G32 Thumb+index pinch        |      120 |  31.7 |     49.2 |  47.5 |  49.2 |
|        33 | G33 Thumb+index+middle pinch |      120 |  29.2 |     52.5 |  34.2 |  44.2 |
|        34 | G34 Thumb+middle pinch       |      120 |  40.8 |     65   |  65.8 |  74.2 |